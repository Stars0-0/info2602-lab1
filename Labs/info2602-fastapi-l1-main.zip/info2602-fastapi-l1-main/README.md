# Info 2602 Lab 1

This is the starter codebase for Task 2 in lab 1.

Use this workspace as a starter to complete the tasks in the lab